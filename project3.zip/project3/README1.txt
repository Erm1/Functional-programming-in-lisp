Collaborators:	Benson Gathee
	       	Abdullah Kokash

Run: Kindly run the program normally (load "project3")

Extra Credit: We did the extra credit